<div class="latepoint-print-summary-w">
	<?php include(LATEPOINT_VIEWS_ABSPATH . 'bookings/_full_summary.php'); ?>
</div>