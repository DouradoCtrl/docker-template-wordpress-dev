<div style="font-size: 16px; margin-bottom: 20px; line-height: 1.6;">
	Dear {{customer_full_name}},
	<br>
	Thank you for creating an account.
</div>
<h4 style="margin-bottom: 10px; margin-top: 0px; font-size: 16px; font-weight: bold;">You can click on <a href="{{customer_dashboard_url}}" target="_blank">this link</a> to access your personal cabinet, where you can:</h4>
<ul style="list-style: square; padding-left: 15px; margin-left: 5px;">
	<li>Manage your appointments</li>
	<li>Update your personal information</li>
	<li>Send messages to your service provider</li>
	<li>Schedule new appointments</li>
	<li>And more...</li>
</ul>