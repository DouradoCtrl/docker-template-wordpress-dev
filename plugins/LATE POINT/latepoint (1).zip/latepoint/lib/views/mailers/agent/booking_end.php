Dear {{agent_full_name}},
<br>
<br>
We hope that your recent appointment with {{customer_full_name}} went well! We are always looking to improve our customer service and would really appreciate your feedback on the experience.
<br>
<br>
You can reply to this email to provide your feedback, it helps us ensure that our customers are getting the best service possible.
<br>
<br>
Thank you for your time.
<br>
Sincerely,
<br>
{{business_name}}