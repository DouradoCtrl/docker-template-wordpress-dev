<div style="padding: 20px; background-color: #f0f0f0; font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;">
	<div style="background-color: #fff; padding: 30px; margin: 0px auto; max-width: 450px; box-shadow: 0px 2px 6px -1px rgba(0,0,0,0.2); border-radius: 6px;">
		<div style="margin: 0px auto 30px auto; border-bottom: 1px solid #eee; padding-bottom: 20px;">
			<table style="width: 100%;">
				<tr>
					<td>{{business_logo_image}}</td>
					<td style="text-align: right;"><span style="color: #7b7b7b;">Questions?</span><br/><strong>{{business_phone}}</strong></td>
				</tr>
			</table>
		</div>
		<div style="font-size: 16px; line-height: 1.5;">
			{{content}}
		</div>
	</div>
	<div style="max-width: 450px; margin: 10px auto; text-align: center;">{{business_address}}</div>
</div>