<div class="latepoint-all-wrapper <?php echo implode(' ', $extra_css_classes); ?>">
	<div class="latepoint-content">
		<?php include($view); ?>
	</div>
</div>