<div class="latepoint-lightbox-heading">
	<h2><?php _e('Booking Summary', 'latepoint'); ?></h2>
</div>
<div class="latepoint-lightbox-content">
<?php include(LATEPOINT_VIEWS_ABSPATH.'bookings/_full_summary.php'); ?>
</div>
