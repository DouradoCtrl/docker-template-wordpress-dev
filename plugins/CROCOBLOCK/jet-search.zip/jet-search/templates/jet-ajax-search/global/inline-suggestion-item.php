<?php
/**
 * Inline Area Item js template
 */
?>

<div class="jet-ajax-search__suggestions-inline-area-item" tabindex="0" aria-label="{{{data}}}">
	<div class="jet-ajax-search__suggestions-inline-area-item-title" >{{{data}}}</div>
</div>
