<?php
/**
 * Results Item js template
 */
?>

<div class="jet-ajax-search__results-suggestions-area-item" tabindex="0" aria-label="{{{data}}}">
	<div class="jet-ajax-search__results-suggestions-area-item-title">{{{data}}}</div>
</div>
