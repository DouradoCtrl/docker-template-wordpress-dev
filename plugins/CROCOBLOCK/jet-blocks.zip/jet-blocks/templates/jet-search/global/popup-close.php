<?php
/**
 * Popup trigger
 */

$this->__icon( 'search_close_icon', '<button type="button" class="jet-search__popup-close"><span class="jet-search__popup-close-icon jet-blocks-icon">%s</span></button>' );
