module.exports = {
	extends: [
		'../.eslintrc.js',
	],
	globals: {
		JetFormCalculatedField: 'readonly',
		JetFormHiddenField: 'readonly',
		JetFormProgressBar: 'readonly',
		JetFormActionButton: 'readonly',
		JetFormBuilderConst: 'readonly',
	},
};