<?php


namespace Jet_Form_Builder\Request\Exceptions;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

use Jet_Form_Builder\Exceptions\Silence_Exception;

class Plain_Value_Exception extends Silence_Exception {

}
