<?php


namespace Jet_Form_Builder\Request\Exceptions;

use Jet_Form_Builder\Exceptions\Handler_Exception;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Sanitize_Value_Exception extends Handler_Exception {

}
