<?php


namespace Jet_Form_Builder\Admin\Exceptions;

use Jet_Form_Builder\Exceptions\Silence_Exception;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Empty_Box_Exception extends Silence_Exception {

}
