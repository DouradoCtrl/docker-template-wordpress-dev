<?php


namespace Jet_Form_Builder\Blocks;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

interface Native_Block_Wrapper_Attributes {

}
