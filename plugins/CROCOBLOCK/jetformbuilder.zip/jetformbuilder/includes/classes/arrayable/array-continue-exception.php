<?php


namespace Jet_Form_Builder\Classes\Arrayable;

use Jet_Form_Builder\Exceptions\Silence_Exception;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Array_Continue_Exception extends Silence_Exception {

}
